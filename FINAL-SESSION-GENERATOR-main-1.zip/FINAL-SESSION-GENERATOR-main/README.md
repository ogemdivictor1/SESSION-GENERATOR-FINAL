# CYPHER PAIRS - WhatsApp session generator (Baileys)

Simple project that uses the Baileys library to create WhatsApp sessions.
Supports QR and Pair Codes for any phone number (owner must scan QR or enter code).

## Quick start (local)
1. Create repo with these files.
2. On your computer, clone and run:
   ```bash
   npm install
   ADMIN_TOKEN="my-secret" node index.js
